function validateLoginForm()
{
	if(document.loginForm.associateId.value==""){
		alert("Enter associateId");
	return false;
	}
	if(document.loginForm.password.value=="")
	{
		alert("Enter associateId");
	return false;
	}
}
function validateRegistrationForm()
{
	if(registerForm.firstName.value=="")
	{
		alert("Enter firstName");
		return false;
	}
	else if(registerForm.lastName.value=="")
	{
		alert("Enter lastName");
		return false;
	}	
	else if(registerForm.email.value=="")
	{
		alert("Enter emailId");
		return false;
	}

}
function validatePassword()
{
	if(changePasswordForm.password.value.length >=6){
		if(changePasswordForm.password.value.search(/[0-9]/)!=-1 && changePasswordForm.password.value.search(/[A-Z]/)!=-1 && 
				changePasswordForm.password.value.search(/[!@#$%^&*()_+]/)!=-1){
			return true;
		}
		else
		{
			alert("password must contain atleast 1 number 1 uppercase letter and 1 special character");
			return false;
		}
	}
	else
	{
		alert("minimum of 6 characters");
		return false;
	}
}
function checkSame()
{
	if(changePasswordForm.password.value!=changePasswordForm.confirmPassword.value)
	{
		alert("password and confirm password did not match");
		return false;
	}
}
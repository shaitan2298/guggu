function sayHello() {
	 document.getElementById("msg").innerHTML="<font color='green' size= 9>Hello World</font>";
	  console.log("Papa");
}
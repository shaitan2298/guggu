package com.cg.project.beans;

public class Associate 
{
    private int associateId;
    private String password,firstName,lastName,mobileNo,email;
    
    public Associate() {}
    
    

	public Associate(int associateId, String password) {
		super();
		this.associateId = associateId;
		this.password = password;
	}



	public Associate(int associateId, String password, String firstName, String lastName, String mobileNo,
			String email) {
		super();
		this.associateId = associateId;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNo = mobileNo;
		this.email = email;
	}



	public int getAssociateId() {
		return associateId;
	}



	public void setAssociateId(int associateId) {
		this.associateId = associateId;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public String getMobileNo() {
		return mobileNo;
	}



	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	@Override
	public String toString() {
		return "Associate [associateId=" + associateId + ", password=" + password + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", mobileNo=" + mobileNo + ", email=" + email + "]";
	}
    
    
    
}
